import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { SceneManager } from '../services/scene';
import { VisionService } from '../services/vision';
import { AudioService } from '../services/audio';
import { AppMode, HandState } from '../types';

interface ExperienceProps {
  onLoaded: () => void;
  onImageAdd: (callback: (file: File) => void) => void;
}

export const Experience: React.FC<ExperienceProps> = ({ onLoaded, onImageAdd }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const sceneMgrRef = useRef<SceneManager | null>(null);
  const visionRef = useRef<VisionService | null>(null);
  const audioRef = useRef<AudioService | null>(null);
  
  // Hand state for logic reference without re-renders
  const handStateRef = useRef<HandState>({
    detected: false,
    x: 0,
    y: 0,
    depthFactor: 0,
    pinchDist: 1,
    avgFingerDist: 1,
    gesture: 'NONE'
  });
  
  const lastSwipeTime = useRef(0);
  const prevHandX = useRef(0);

  // Expose image adding capability
  useEffect(() => {
    onImageAdd((file: File) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result && sceneMgrRef.current) {
          const loader = new THREE.TextureLoader();
          loader.load(e.target.result as string, (tex) => {
             sceneMgrRef.current?.addPhoto(tex);
          });
        }
      };
      reader.readAsDataURL(file);
    });
  }, [onImageAdd]);

  useEffect(() => {
    if (!containerRef.current || !videoRef.current) return;

    // 1. Init Audio
    audioRef.current = new AudioService();

    // 2. Init Scene
    const sceneMgr = new SceneManager(containerRef.current);
    sceneMgrRef.current = sceneMgr;

    // Load Default Photo
    new THREE.TextureLoader().load('https://picsum.photos/400/400', (tex) => {
      sceneMgr.addPhoto(tex);
    });

    // 3. Init Vision
    const vision = new VisionService();
    visionRef.current = vision;

    const start = async () => {
      try {
        await navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
          if (videoRef.current) videoRef.current.srcObject = stream;
        });

        await vision.init(videoRef.current!);
        
        onLoaded();

        vision.startPrediction((state) => {
          handStateRef.current = state;
          handleGestures(state, sceneMgr);
        });

        // Start Animation Loop
        const animate = () => {
          sceneMgr.update(handStateRef.current);
          requestAnimationFrame(animate);
        };
        animate();

      } catch (err) {
        console.error("Initialization failed:", err);
      }
    };

    start();

    // Unlock Audio Context on first interaction
    const unlockAudio = () => {
      audioRef.current?.resume();
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
    };
    window.addEventListener('click', unlockAudio);
    window.addEventListener('touchstart', unlockAudio);

    const handleResize = () => sceneMgr.resize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
      vision.stop();
      sceneMgr.cleanup();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleGestures = (state: HandState, mgr: SceneManager) => {
    if (!state.detected) return;

    // Mode Switching
    if (state.gesture === 'PINCH') {
       if (mgr.mode !== AppMode.FOCUS) {
          mgr.setMode(AppMode.FOCUS);
          audioRef.current?.playDing(); // Sound: Ding
          lastSwipeTime.current = performance.now(); // Reset swipe
       }
    } else if (state.gesture === 'CLOSED') {
       if (mgr.mode !== AppMode.TREE) {
         mgr.setMode(AppMode.TREE);
         audioRef.current?.playGather(); // Sound: Gather
       }
    } else if (state.gesture === 'OPEN') {
       if (mgr.mode !== AppMode.SCATTER) {
         mgr.setMode(AppMode.SCATTER);
         audioRef.current?.playSparkle(); // Sound: Sparkle
       }
    }

    // Swipe Logic (Focus Mode)
    if (mgr.mode === AppMode.FOCUS) {
      const now = performance.now();
      const deltaX = state.x - prevHandX.current;
      const swipeThreshold = 0.05;
      const debounce = 500;

      if (now - lastSwipeTime.current > debounce) {
        if (deltaX < -swipeThreshold || deltaX > swipeThreshold) {
          mgr.navigatePhotos(1);
          lastSwipeTime.current = now;
          audioRef.current?.playWhoosh(); // Sound: Whoosh
        }
      }
    }

    prevHandX.current = state.x;
  };

  return (
    <>
      <div ref={containerRef} className="absolute top-0 left-0 w-full h-full z-[1]" />
      <div className="absolute bottom-10 right-10 w-32 h-24 border border-white/10 opacity-0 pointer-events-none overflow-hidden">
        <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
      </div>
    </>
  );
};