import React, { useRef } from 'react';

interface UIProps {
  isLoading: boolean;
  onUpload: (files: FileList | null) => void;
}

export const UI: React.FC<UIProps> = ({ isLoading, onUpload }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpload(e.target.files);
  };

  return (
    <>
      {/* Loader */}
      <div
        className={`absolute inset-0 z-50 flex flex-col items-center justify-center bg-black transition-opacity duration-1000 ${
          isLoading ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="w-10 h-10 border border-[#d4af37]/20 border-t-[#d4af37] rounded-full animate-spin-slow mb-6" />
        <div className="text-[#d4af37] text-sm tracking-[4px] uppercase font-thin">
          Loading Holiday Magic
        </div>
      </div>

      {/* Main UI */}
      <div className={`absolute top-0 left-0 w-full h-full z-10 pointer-events-none flex flex-col items-center pt-10 transition-opacity duration-1000 ${isLoading ? 'opacity-0' : 'opacity-100'}`}>
        <h1 className="text-4xl md:text-6xl font-normal tracking-[6px] bg-clip-text text-transparent bg-gradient-to-b from-white to-[#eebb66] drop-shadow-[0_0_50px_rgba(252,238,167,0.6)] font-['Cinzel'] opacity-90 text-center px-4">
          Merry Christmas
        </h1>

        <div className="absolute bottom-10 right-10 pointer-events-auto text-center animate-fade-in-up">
          <label className="group relative inline-block cursor-pointer">
            <div className="absolute inset-0 bg-[#d4af37] blur opacity-20 group-hover:opacity-40 transition-opacity duration-500 rounded"></div>
            <div className="relative bg-neutral-900/80 border border-[#d4af37]/40 text-[#d4af37] px-6 py-3 uppercase tracking-[3px] text-[10px] hover:bg-[#d4af37] hover:text-black transition-all duration-300 backdrop-blur-sm shadow-[0_0_15px_rgba(212,175,55,0.1)] group-hover:shadow-[0_0_25px_rgba(212,175,55,0.4)]">
              Add Memories
            </div>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />
          </label>
          <div className="text-[#d4af37]/50 text-[9px] mt-2 tracking-widest uppercase">
            Pinch to Focus • Open to Scatter
          </div>
        </div>
      </div>
    </>
  );
};