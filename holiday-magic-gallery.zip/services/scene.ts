import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment';
import { AppMode, SceneConfig, HandState } from '../types';

export const DEFAULT_CONFIG: SceneConfig = {
  colors: {
    bg: 0x000000,
    champagneGold: 0xffd966,
    deepGreen: 0x03180a,
    accentRed: 0x990000,
  },
  particles: {
    count: 1500,
    dustCount: 2500,
    treeHeight: 24,
    treeRadius: 8,
  },
  camera: {
    defaultZ: 50,
  },
};

class Particle {
  mesh: THREE.Mesh | THREE.Group;
  type: string;
  isDust: boolean;
  posTree: THREE.Vector3 = new THREE.Vector3();
  posScatter: THREE.Vector3 = new THREE.Vector3();
  baseScale: number;
  spinSpeed: THREE.Vector3;
  id: number;

  constructor(mesh: THREE.Mesh | THREE.Group, type: string, isDust: boolean = false) {
    this.mesh = mesh;
    this.type = type;
    this.isDust = isDust;
    this.baseScale = mesh.scale.x;
    this.id = Math.random();

    const speedMult = type === "PHOTO" ? 0.3 : 2.0;
    this.spinSpeed = new THREE.Vector3(
      (Math.random() - 0.5) * speedMult,
      (Math.random() - 0.5) * speedMult,
      (Math.random() - 0.5) * speedMult
    );

    this.calculatePositions();
  }

  calculatePositions() {
    const h = DEFAULT_CONFIG.particles.treeHeight;
    const halfH = h / 2;
    let t = Math.random();
    t = Math.pow(t, 0.8);
    const y = t * h - halfH;
    let rMax = DEFAULT_CONFIG.particles.treeRadius * (1.0 - t);
    if (rMax < 0.5) rMax = 0.5;
    const angle = t * 50 * Math.PI + Math.random() * Math.PI;
    const r = rMax * (0.8 + Math.random() * 0.4);
    this.posTree.set(Math.cos(angle) * r, y, Math.sin(angle) * r);

    let rScatter = this.isDust
      ? 12 + Math.random() * 20
      : 8 + Math.random() * 12;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    this.posScatter.set(
      rScatter * Math.sin(phi) * Math.cos(theta),
      rScatter * Math.sin(phi) * Math.sin(theta),
      rScatter * Math.cos(phi)
    );
  }

  update(dt: number, mode: AppMode, focusTargetMesh: THREE.Object3D | null, cameraPos: THREE.Vector3, elapsedTime: number) {
    let target = this.posTree;

    if (mode === AppMode.SCATTER) target = this.posScatter;
    else if (mode === AppMode.FOCUS) {
      if (this.mesh === focusTargetMesh) {
        // Bring focused photo to front center relative to camera roughly
        // Ideally we project to world, but here we hardcode for the static camera setup
        // Modified to ensure it's in front of camera
        target = new THREE.Vector3(0, 2, 35); 
      } else {
        target = this.posScatter;
      }
    }

    // Movement Easing
    const lerpSpeed = (mode === AppMode.FOCUS && this.mesh === focusTargetMesh) ? 5.0 : 2.0;
    this.mesh.position.lerp(target, lerpSpeed * dt);

    // Rotation
    if (mode === AppMode.SCATTER) {
      this.mesh.rotation.x += this.spinSpeed.x * dt;
      this.mesh.rotation.y += this.spinSpeed.y * dt;
      this.mesh.rotation.z += this.spinSpeed.z * dt;
    } else if (mode === AppMode.TREE) {
      this.mesh.rotation.x = THREE.MathUtils.lerp(this.mesh.rotation.x, 0, dt);
      this.mesh.rotation.z = THREE.MathUtils.lerp(this.mesh.rotation.z, 0, dt);
      this.mesh.rotation.y += 0.5 * dt;
    }

    if (mode === AppMode.FOCUS && this.mesh === focusTargetMesh) {
      this.mesh.lookAt(cameraPos);
    }

    // Scale Logic
    let s = this.baseScale;
    if (this.isDust) {
      s = this.baseScale * (0.8 + 0.4 * Math.sin(elapsedTime * 4 + this.id));
      if (mode === AppMode.TREE) s = 0;
    } else if (mode === AppMode.SCATTER && this.type === "PHOTO") {
      s = this.baseScale * 2.5;
    } else if (mode === AppMode.FOCUS) {
      if (this.mesh === focusTargetMesh) s = 4.5;
      else s = this.baseScale * 0.8;
    }
    
    // Scale smoothing
    this.mesh.scale.lerp(new THREE.Vector3(s, s, s), 4 * dt);
  }
}

export class SceneManager {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  composer: EffectComposer;
  mainGroup: THREE.Group;
  photoMeshGroup: THREE.Group;
  clock: THREE.Clock;
  
  particles: Particle[] = [];
  photoParticles: Particle[] = [];
  
  mode: AppMode = AppMode.TREE;
  focusIndex: number = -1;
  hasSeenIntro: boolean = false;
  focusTarget: THREE.Object3D | null = null;
  
  // Rotation state
  rotation = { x: 0, y: 0 };
  
  constructor(container: HTMLElement) {
    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(DEFAULT_CONFIG.colors.bg);
    this.scene.fog = new THREE.FogExp2(DEFAULT_CONFIG.colors.bg, 0.01);

    // Camera
    this.camera = new THREE.PerspectiveCamera(42, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.camera.position.set(0, 2, DEFAULT_CONFIG.camera.defaultZ);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ReinhardToneMapping;
    this.renderer.toneMappingExposure = 2.2;
    container.appendChild(this.renderer.domElement);

    // Groups
    this.mainGroup = new THREE.Group();
    this.scene.add(this.mainGroup);
    
    this.photoMeshGroup = new THREE.Group();
    this.mainGroup.add(this.photoMeshGroup);

    // Setup
    this.clock = new THREE.Clock();
    this.setupEnvironment();
    this.setupLights();
    this.setupPostProcessing();
    this.createParticles();
    this.createDust();
  }

  private setupEnvironment() {
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
  }

  private setupLights() {
    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambient);

    const innerLight = new THREE.PointLight(0xffaa00, 2, 20);
    innerLight.position.set(0, 5, 0);
    this.mainGroup.add(innerLight);

    const spotGold = new THREE.SpotLight(0xffcc66, 1200);
    spotGold.position.set(30, 40, 40);
    spotGold.angle = 0.5;
    spotGold.penumbra = 0.5;
    this.scene.add(spotGold);

    const fill = new THREE.DirectionalLight(0xffeebb, 0.8);
    fill.position.set(0, 0, 50);
    this.scene.add(fill);
  }

  private setupPostProcessing() {
    const renderScene = new RenderPass(this.scene, this.camera);
    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      1.5, 0.4, 0.85
    );
    bloomPass.threshold = 0.7;
    bloomPass.strength = 0.45;
    bloomPass.radius = 0.4;

    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(renderScene);
    this.composer.addPass(bloomPass);
  }

  private createParticles() {
    // Geometries & Materials
    const sphereGeo = new THREE.SphereGeometry(0.5, 32, 32);
    const boxGeo = new THREE.BoxGeometry(0.55, 0.55, 0.55);
    
    // Candy Cane
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.5, 0),
      new THREE.Vector3(0, 0.3, 0),
      new THREE.Vector3(0.1, 0.5, 0),
      new THREE.Vector3(0.3, 0.4, 0),
    ]);
    const candyGeo = new THREE.TubeGeometry(curve, 16, 0.08, 8, false);

    // Cane Texture
    const canvas = document.createElement("canvas");
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext("2d");
    if (ctx) {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, 128, 128);
        ctx.fillStyle = "#880000";
        ctx.beginPath();
        for (let i = -128; i < 256; i += 32) {
            ctx.moveTo(i, 0);
            ctx.lineTo(i + 32, 128);
            ctx.lineTo(i + 16, 128);
            ctx.lineTo(i - 16, 0);
        }
        ctx.fill();
    }
    const caneTexture = new THREE.CanvasTexture(canvas);
    caneTexture.wrapS = THREE.RepeatWrapping;
    caneTexture.wrapT = THREE.RepeatWrapping;
    caneTexture.repeat.set(3, 3);


    const goldMat = new THREE.MeshStandardMaterial({
      color: DEFAULT_CONFIG.colors.champagneGold,
      metalness: 1.0,
      roughness: 0.1,
      emissive: 0x443300,
      emissiveIntensity: 0.3,
    });

    const greenMat = new THREE.MeshStandardMaterial({
      color: DEFAULT_CONFIG.colors.deepGreen,
      metalness: 0.2,
      roughness: 0.8,
      emissive: 0x002200,
      emissiveIntensity: 0.2,
    });

    const redMat = new THREE.MeshPhysicalMaterial({
      color: DEFAULT_CONFIG.colors.accentRed,
      metalness: 0.3,
      roughness: 0.2,
      clearcoat: 1.0,
      emissive: 0x330000,
    });

    const candyMat = new THREE.MeshStandardMaterial({
      map: caneTexture,
      roughness: 0.4,
    });

    for (let i = 0; i < DEFAULT_CONFIG.particles.count; i++) {
      const rand = Math.random();
      let mesh, type;

      if (rand < 0.4) {
        mesh = new THREE.Mesh(boxGeo, greenMat);
        type = "BOX";
      } else if (rand < 0.7) {
        mesh = new THREE.Mesh(boxGeo, goldMat);
        type = "GOLD_BOX";
      } else if (rand < 0.92) {
        mesh = new THREE.Mesh(sphereGeo, goldMat);
        type = "GOLD_SPHERE";
      } else if (rand < 0.97) {
        mesh = new THREE.Mesh(sphereGeo, redMat);
        type = "RED";
      } else {
        mesh = new THREE.Mesh(candyGeo, candyMat);
        type = "CANE";
      }

      const s = 0.4 + Math.random() * 0.5;
      mesh.scale.set(s, s, s);
      mesh.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);

      this.mainGroup.add(mesh);
      this.particles.push(new Particle(mesh, type, false));
    }

    // Star
    const starGeo = new THREE.OctahedronGeometry(1.2, 0);
    const starMat = new THREE.MeshStandardMaterial({
      color: 0xffdd88,
      emissive: 0xffaa00,
      emissiveIntensity: 1.0,
    });
    const star = new THREE.Mesh(starGeo, starMat);
    star.position.set(0, DEFAULT_CONFIG.particles.treeHeight / 2 + 1.2, 0);
    this.mainGroup.add(star);
  }

  private createDust() {
    const geo = new THREE.TetrahedronGeometry(0.08, 0);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xffeebb,
      transparent: true,
      opacity: 0.8,
    });
    for (let i = 0; i < DEFAULT_CONFIG.particles.dustCount; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      mesh.scale.setScalar(0.5 + Math.random());
      this.mainGroup.add(mesh);
      this.particles.push(new Particle(mesh, "DUST", true));
    }
  }

  public addPhoto(texture: THREE.Texture) {
    texture.colorSpace = THREE.SRGBColorSpace;
    const frameGeo = new THREE.BoxGeometry(1.4, 1.4, 0.05);
    const frameMat = new THREE.MeshStandardMaterial({
      color: DEFAULT_CONFIG.colors.champagneGold,
      metalness: 1.0,
      roughness: 0.1,
    });
    const frame = new THREE.Mesh(frameGeo, frameMat);

    const photoGeo = new THREE.PlaneGeometry(1.2, 1.2);
    const photoMat = new THREE.MeshBasicMaterial({ map: texture });
    const photo = new THREE.Mesh(photoGeo, photoMat);
    photo.position.z = 0.04;

    const group = new THREE.Group();
    group.add(frame);
    group.add(photo);

    const s = 0.8;
    group.scale.set(s, s, s);

    this.photoMeshGroup.add(group);
    const p = new Particle(group, "PHOTO", false);
    this.particles.push(p);
    this.photoParticles.push(p);
  }

  public setMode(newMode: AppMode) {
    if (this.mode === newMode) return;
    this.mode = newMode;
    
    if (newMode === AppMode.FOCUS && this.photoParticles.length > 0) {
      if (this.focusIndex === -1) {
        this.focusIndex = 0;
        this.hasSeenIntro = true;
      }
      this.focusTarget = this.photoParticles[this.focusIndex].mesh;
    } else if (newMode !== AppMode.FOCUS) {
      this.focusTarget = null;
    }
  }

  public navigatePhotos(direction: number) {
    if (this.photoParticles.length === 0) return;
    
    let nextIndex = this.focusIndex + direction;
    const count = this.photoParticles.length;

    if (nextIndex >= count) nextIndex = 0;
    if (nextIndex < 0) nextIndex = count - 1;

    // Smart skip default logic
    if (this.hasSeenIntro && count > 1 && nextIndex === 0) {
      nextIndex = (direction > 0) ? 1 : count - 1;
    }

    this.focusIndex = nextIndex;
    this.focusTarget = this.photoParticles[this.focusIndex].mesh;
  }

  public update(handState: HandState) {
    const dt = this.clock.getDelta();
    const elapsedTime = this.clock.getElapsedTime();

    // Camera Logic
    let targetZ = DEFAULT_CONFIG.camera.defaultZ;
    if (this.mode === AppMode.SCATTER && handState.detected) {
      // Map hand size 0.15-0.4 to Z 80-20
      const minHand = 0.15;
      const maxHand = 0.4;
      const factor = THREE.MathUtils.clamp((handState.depthFactor - minHand) / (maxHand - minHand), 0, 1);
      targetZ = THREE.MathUtils.lerp(80, 20, factor);
    }
    this.camera.position.z += (targetZ - this.camera.position.z) * 2.0 * dt;

    // Rotation Logic
    if (this.mode === AppMode.SCATTER && handState.detected) {
      const targetRotY = handState.x * Math.PI * 0.9;
      const targetRotX = handState.y * Math.PI * 0.25;
      this.rotation.y += (targetRotY - this.rotation.y) * 3.0 * dt;
      this.rotation.x += (targetRotX - this.rotation.x) * 3.0 * dt;
    } else {
      if (this.mode === AppMode.TREE) {
        this.rotation.y += 0.3 * dt;
        this.rotation.x += (0 - this.rotation.x) * 2.0 * dt;
      } else {
        this.rotation.y += 0.1 * dt;
      }
    }

    this.mainGroup.rotation.y = this.rotation.y;
    this.mainGroup.rotation.x = this.rotation.x;

    // Update Particles
    this.particles.forEach(p => p.update(dt, this.mode, this.focusTarget, this.camera.position, elapsedTime));

    this.composer.render();
  }

  public resize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.composer.setSize(window.innerWidth, window.innerHeight);
  }

  public cleanup() {
    this.renderer.dispose();
    this.composer.dispose();
  }
}