export class AudioService {
  private ctx: AudioContext | null = null;
  // C6 Pentatonic Scale frequencies for magical sparkles
  private scale = [1046.50, 1174.66, 1318.51, 1567.98, 1760.00, 2093.00]; 

  constructor() {
    if (typeof window !== 'undefined') {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
  }

  async resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
  }

  // Effect: Magical high-pitched sparkles
  playSparkle() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    
    // Play 5 random notes from the scale
    for(let i=0; i<5; i++) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      const freq = this.scale[Math.floor(Math.random() * this.scale.length)];
      osc.frequency.value = freq;
      osc.type = 'sine';
      
      const timeOffset = i * 0.05 + Math.random() * 0.05;
      
      // Short envelope
      gain.gain.setValueAtTime(0, now + timeOffset);
      gain.gain.linearRampToValueAtTime(0.05, now + timeOffset + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + timeOffset + 0.5);
      
      osc.start(now + timeOffset);
      osc.stop(now + timeOffset + 0.6);
    }
  }

  // Effect: Clear bell ding for selection
  playDing() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    
    // Fundamental tone
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    
    osc.frequency.setValueAtTime(880, now); // A5
    osc.type = 'sine';
    
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.2, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 1.0);
    
    osc.start(now);
    osc.stop(now + 1.1);

    // Subtle Overtone for richness
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.connect(gain2);
    gain2.connect(this.ctx.destination);
    osc2.frequency.setValueAtTime(880 * 2.5, now);
    osc2.type = 'sine';
    gain2.gain.setValueAtTime(0, now);
    gain2.gain.linearRampToValueAtTime(0.05, now + 0.02);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    osc2.start(now);
    osc2.stop(now + 0.5);
  }

  // Effect: Warm chord for gathering/tree mode
  playGather() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    
    // Soft C Major chord pad
    const freqs = [261.63, 329.63, 392.00]; 
    freqs.forEach((f) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        
        osc.frequency.value = f;
        osc.type = 'sine';
        
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.05, now + 0.1);
        gain.gain.linearRampToValueAtTime(0, now + 0.6);
        
        osc.start(now);
        osc.stop(now + 0.7);
    });
  }

  // Effect: Airy whoosh for navigation
  playWhoosh() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    
    // White noise buffer
    const bufferSize = this.ctx.sampleRate * 0.4;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    // Filter sweep
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.Q.value = 1;
    filter.frequency.setValueAtTime(600, now);
    filter.frequency.linearRampToValueAtTime(2000, now + 0.2);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.1, now + 0.1);
    gain.gain.linearRampToValueAtTime(0, now + 0.3);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    noise.start(now);
    noise.stop(now + 0.4);
  }
}