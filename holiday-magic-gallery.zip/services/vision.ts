import { FilesetResolver, HandLandmarker, HandLandmarkerResult } from '@mediapipe/tasks-vision';
import { HandState } from '../types';

export class VisionService {
  private handLandmarker: HandLandmarker | null = null;
  private video: HTMLVideoElement | null = null;
  private lastVideoTime = -1;
  private animationFrameId: number | null = null;

  async init(videoElement: HTMLVideoElement): Promise<void> {
    this.video = videoElement;
    
    const vision = await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3/wasm"
    );
    
    this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
        delegate: "GPU",
      },
      runningMode: "VIDEO",
      numHands: 1,
    });
  }

  startPrediction(onResult: (state: HandState) => void): void {
    if (!this.handLandmarker || !this.video) return;

    const predict = () => {
      if (this.video && this.handLandmarker) {
        if (this.video.currentTime !== this.lastVideoTime) {
          this.lastVideoTime = this.video.currentTime;
          const result = this.handLandmarker.detectForVideo(this.video, performance.now());
          const state = this.processResults(result);
          onResult(state);
        }
      }
      this.animationFrameId = requestAnimationFrame(predict);
    };

    this.animationFrameId = requestAnimationFrame(predict);
  }

  stop(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }

  private processResults(result: HandLandmarkerResult): HandState {
    if (!result.landmarks || result.landmarks.length === 0) {
      return {
        detected: false,
        x: 0,
        y: 0,
        depthFactor: 0,
        pinchDist: 1,
        avgFingerDist: 1,
        gesture: 'NONE'
      };
    }

    const lm = result.landmarks[0];
    const wrist = lm[0];
    const middle = lm[9];
    const thumb = lm[4];
    const index = lm[8];

    // Normalized coordinates (-1 to 1)
    const currX = (middle.x - 0.5) * 2;
    const currY = (middle.y - 0.5) * 2;

    // Depth approximation
    const handSize = Math.hypot(middle.x - wrist.x, middle.y - wrist.y);

    // Pinch distance
    const pinchDist = Math.hypot(thumb.x - index.x, thumb.y - index.y);

    // Average finger spread (open palm detection)
    const tips = [lm[8], lm[12], lm[16], lm[20]];
    let totalDist = 0;
    tips.forEach(t => {
      totalDist += Math.hypot(t.x - wrist.x, t.y - wrist.y);
    });
    const avgFingerDist = totalDist / 4;

    let gesture: HandState['gesture'] = 'NONE';
    if (pinchDist < 0.05) gesture = 'PINCH';
    else if (avgFingerDist > 0.4) gesture = 'OPEN';
    else if (avgFingerDist < 0.25) gesture = 'CLOSED';

    return {
      detected: true,
      x: currX,
      y: currY,
      depthFactor: handSize,
      pinchDist,
      avgFingerDist,
      gesture
    };
  }
}